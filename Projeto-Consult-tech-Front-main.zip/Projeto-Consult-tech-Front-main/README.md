# Consult Tech (Vanilla HTML/CSS/JS)

Abra `index.html` ou `login/login.html` no navegador.

## Mudanças feitas
- Mudança na tela de cadastro retirando telefone e colocando o campo confirmar senha  
- Remoção dos pop-ups em algumas telas 

## Integração com backend
Edite `assets/js/api.js` e ajuste `API_BASE` para apontar ao seu Spring Boot.
